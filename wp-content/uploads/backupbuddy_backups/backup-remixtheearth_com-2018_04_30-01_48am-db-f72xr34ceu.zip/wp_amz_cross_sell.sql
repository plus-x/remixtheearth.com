CREATE TABLE `wp_amz_cross_sell` (  `ASIN` varchar(10) COLLATE utf8_unicode_ci NOT NULL,  `products` text COLLATE utf8_unicode_ci,  `nr_products` int(11) DEFAULT NULL,  `add_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  `is_variable` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',  `nb_tries` tinyint(1) unsigned DEFAULT '0',  PRIMARY KEY (`ASIN`),  UNIQUE KEY `ASIN` (`ASIN`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `wp_amz_cross_sell` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_amz_cross_sell` ENABLE KEYS */;

CREATE TABLE `wp_commentmeta` (  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `meta_value` longtext COLLATE utf8mb4_unicode_ci,  PRIMARY KEY (`meta_id`),  KEY `comment_id` (`comment_id`),  KEY `meta_key` (`meta_key`(191))) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
INSERT INTO `wp_commentmeta` VALUES('5', '2', 'akismet_history', 'a:2:{s:4:\"time\";d:1499824383.618072986602783203125;s:5:\"event\";s:9:\"check-ham\";}');
INSERT INTO `wp_commentmeta` VALUES('4', '2', 'akismet_result', 'false');
INSERT INTO `wp_commentmeta` VALUES('7', '2', 'akismet_history', 'a:3:{s:4:\"time\";d:1503080686.8269960880279541015625;s:5:\"event\";s:15:\"status-approved\";s:4:\"user\";s:5:\"admin\";}');
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
